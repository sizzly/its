CONTENTS OF THIS FILE
---------------------

* Requirements
* Configuration

REQUIREMENTS
------------

* Drupal 7.x
* Chaos Tools
* Field Collection

CONFIGURATION
-------------
No configuration is needed.  When module is active, any field collection add /
edit / delete links will be converted to use CTools modals for presentation of
data to the end user for CRUD functions.
