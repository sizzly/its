<?php

/**
 * @file
 * Definition of Drupal\configuration\Storage\StorageYaml.
 */
